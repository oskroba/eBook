﻿
WAF.onAfterInit = function onAfterInit() {// @lock

// @region namespaceDeclaration// @startlock
// @endregion// @endlock

// eventHandlers// @lock

// @region eventManager// @startlock
// @endregion
};// @endlock
